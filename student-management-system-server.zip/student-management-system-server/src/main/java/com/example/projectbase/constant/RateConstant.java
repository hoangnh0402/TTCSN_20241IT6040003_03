package com.example.projectbase.constant;

public class RateConstant {
    public static final String EXCElLENT = "Xuất sắc";
    public static final String GOOD = "Giỏi";
    public static final String RATHER = "Khá";
    public static final String MEDIUM = "Trung bình";
    public static final String WEAK = "Yếu/Kém";
    public static final String UNKNOWN = "Chưa đánh giá";
}
