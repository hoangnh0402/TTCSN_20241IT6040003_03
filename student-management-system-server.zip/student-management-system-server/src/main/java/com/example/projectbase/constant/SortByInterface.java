package com.example.projectbase.constant;

@FunctionalInterface
public interface SortByInterface {

  String getSortBy(String sortBy);

}
