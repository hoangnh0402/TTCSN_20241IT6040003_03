package com.example.projectbase.constant;

public class RoleConstant {
  public static final String ADMIN = "ROLE_ADMIN";
  public static final String STUDENT = "ROLE_STUDENT";
  public static final String TEACHER = "ROLE_TEACHER";
}
