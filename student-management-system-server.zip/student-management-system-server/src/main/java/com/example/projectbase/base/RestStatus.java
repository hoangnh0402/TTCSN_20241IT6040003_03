package com.example.projectbase.base;

public enum RestStatus {
  SUCCESS, ERROR
}
