package com.example.projectbase.constant;

public class MessageConstrant {
    public static final String SUCCESS = "success";
    public static final String FAIL = "fail";
}